<!DOCTYPE html>
    <head>
        <title>Main Page</title>

        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">

        <link href="<?php echo e(URL::asset('css/pageStyle.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(URL::asset('css/topbarStyle.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(URL::asset('css/sidenavStyle.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(URL::asset('css/tableStyle.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(URL::asset('css/popupStyle.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(URL::asset('css/formStyle.css')); ?>" rel="stylesheet">

    </head>
    <body>
        <div id="topbar">
            <div id="userArea">
            </div>

            <h1 id="title"><a href=''>XHIBIT</a></h1>

            <div></div>

            </div>
        </div>
        <div id="loginPage">
            <div id="loginForm">
                <?php if(auth()->guard()->guest()): ?>
                    <?php if(Route::has('login')): ?>
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                            <label for="email" class=""><?php echo e(__('E-Mail Address')); ?></label>
                                
                                <input id="email" type="email" class="" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="off" autofocus>
                            
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <label for="password" class=""><?php echo e(__('Password')); ?></label>  
                                
                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                            
                            <?php if(Route::has('password.request')): ?>
                                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                    <?php echo e(__('Forgot Your Password?')); ?>

                                </a>
                            <?php endif; ?>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="inputContainer">
                                <label class="form-check-label" for="remember">
                                        <?php echo e(__('Remember Me')); ?>

                                </label>
                                <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                
                            </div>
                            
                            <button type="submit" class="btn btn-primary" id="loginBtn">
                                <?php echo e(__('Login')); ?>

                            </button>

                            
                            <hr>  
                              
                    </form>
                    <?php endif; ?>
                        
                    <?php if(Route::has('register')): ?>
                    <div style="text-align: center;">
                    <br>
                        <p>Dont Have an Account?</p>
                        
                        <a class="nav-link" href="<?php echo e(route('register')); ?>">
                            Register                        
                        </a>
                    </div>
                            
                            
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            
               
        </div>
    </body>

    <script>
        // Get the modal
        var modal = document.getElementById("myModal");

        // Get the button that opens the modal
        var btn = document.getElementById("myBtn");

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];

        // When the user clicks on the button, open the modal
        btn.onclick = function() {
            modal.style.display = "block";
        }

        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
            modal.style.display = "none";
        }

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
</html>
<?php /**PATH C:\Users\reigi\Desktop\ExhibitApp-main\resources\views/auth/login.blade.php ENDPATH**/ ?>