<?php $__env->startSection('sidebar'); ?>
    <ul id="nav">
        <a href="/"><li id="allTab">All</li></a>
        <a href="/artTable"><li class="subTab">art</li></a>
        <a href="/exhibitsTable"><li class="subTab">exhibits</li></a>
        <a href="/musicTable"><li class="subTab">music</li></a>
        <a href="/poetriesTable"><li class="subTab">poetries</li></a>
        <a href="/transactionsTable"><li class="subTab">transactions</li></a>
        <?php if(Auth::user()->admin == true): ?>
            <a href="/usersTable"><li class="subTab">users</li></a>
        <?php endif; ?>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form action="/insertUser" method="post">
        <?php echo csrf_field(); ?>
        <h1>USER FORM</h1>
        <input type="hidden" name="id"value="<?php echo e($user['id']); ?>">
        <label for="name">Name</label>
            <input type="text" name="name" required value="<?php echo e($user['name']); ?>">
        <label for="email">Email Address</label>
            <input type="email" name="email" required value="<?php echo e($user['email']); ?>">

        <!-- <label for="password">Password</label> -->
            <input type="hidden" name="password" required value="<?php echo e($user['password']); ?>">
        <label for="admin">Admin Privileges</label>
            <input type="checkbox" name="admin"value="<?php echo e($user['admin']); ?>">
        <button id="submitBtn"><h3>SUBMIT</h3></button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../formLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\reigi\Desktop\ExhibitApp-main\resources\views/forms/updateUser.blade.php ENDPATH**/ ?>