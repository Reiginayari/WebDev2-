<?php $__env->startSection('sidebar'); ?>
    <ul id="nav">
        <a href="/"><li id="allTab">All</li></a>
        <a href="/artTable"><li class="subTab">art</li></a>
        <a href="/exhibitsTable"><li class="subTab">exhibits</li></a>
        <a href="/musicTable"><li class="subTab">music</li></a>
        <a href="/poetriesTable"><li class="subTab">poetries</li></a>
        <a href="/transactionsTable"><li class="subTab">transactions</li></a>
        <?php if(Auth::user()->admin == true): ?>
            <a href="/usersTable"><li class="subTab">users</li></a>
        <?php endif; ?>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form action="/updateArt" method="post">
        <?php echo csrf_field(); ?>
        <h1>UPDATE ART FORM</h1>
        
        <input type="hidden" name="id" value="<?php echo e($art['id']); ?>">

        <label for="artTitle">Art Title</label>
            <input type="text" name="artTitle" value="<?php echo e($art['ArtTitle']); ?>" required>

        <label for="artType">Art Type (music / poetry)</label>
            <input type="text" name="artType" value="<?php echo e($art['ArtType']); ?>" required>

        <input type="hidden" name="userID" value="<?php echo e(Auth::user()->id); ?>">
        <button id="submitBtn"><h3>SUBMIT</h3></button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../formLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\reigi\Desktop\ExhibitApp-main\resources\views/forms/updateArt.blade.php ENDPATH**/ ?>