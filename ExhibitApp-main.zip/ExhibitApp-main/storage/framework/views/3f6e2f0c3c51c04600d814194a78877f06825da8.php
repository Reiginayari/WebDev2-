<?php $__env->startSection('sidebar'); ?>
<ul id="nav">
        <a href="/"><li id="allTab">All</li></a>
        <a href="/artTable"><li class="subTab">art</li></a>
        <a href="/exhibitsTable"><li class="subTab">exhibits</li></a>
        <a href="/musicTable"><li class="subTab">music</li></a>
        <a href="/poetriesTable"><li class="subTab">poetries</li></a>
        <a href="/transactionsTable"><li class="subTab">transactions</li></a>
        <?php if(Auth::user()->admin == true): ?>
            <a href="/usersTable"><li class="subTab">users</li></a>
        <?php endif; ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="/insertPoetry" method="post">
        <?php echo csrf_field(); ?>
        <h1>POETRY FORM</h1>

        <label for="poetryTitle">Poetry Title</label>
            <input type="text" name="poetryTitle" required>

        <input type="hidden" name="userID" value="<?php echo e(Auth::user()->id); ?>">
        <button id="submitBtn"><h3>SUBMIT</h3></button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../formLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\reigi\Desktop\ExhibitApp-main\resources\views/forms/newPoetry.blade.php ENDPATH**/ ?>