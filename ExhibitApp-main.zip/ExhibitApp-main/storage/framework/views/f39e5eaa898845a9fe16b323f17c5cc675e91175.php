<html>
    <head>
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">

        <link href="<?php echo e(URL::asset('css/pageStyle.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(URL::asset('css/topbarStyle.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(URL::asset('css/sidenavStyle.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(URL::asset('css/tableStyle.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(URL::asset('css/formStyle.css')); ?>" rel="stylesheet">
    </head>
    <body>
    <div id="topbar">
            <div id="userArea">

                <svg id="icon" xmlns="http://www.w3.org/2000/svg" width="1.25em" height="1.25em" viewBox="0 0 36 36">
                    <path id="Icon_awesome-user-alt" data-name="Icon awesome-user-alt" d="M18,20.25A10.125,10.125,0,1,0,7.875,10.125,10.128,10.128,0,0,0,18,20.25Zm9,2.25H23.126a12.24,12.24,0,0,1-10.252,0H9a9,9,0,0,0-9,9v1.125A3.376,3.376,0,0,0,3.375,36h29.25A3.376,3.376,0,0,0,36,32.625V31.5A9,9,0,0,0,27,22.5Z" fill="#fff"/>
                </svg>          
                <?php if(auth()->guard()->guest()): ?>
                    <?php if(Route::has('login')): ?>
                        <h5 id="userName">Guest Account</h5>   
                    <?php endif; ?>

                    <?php else: ?>
                        <h5 id="userName"><?php echo e(Auth::user()->name); ?></h4>
                <?php endif; ?>
            </div>

            <h1 id="title"><a href='/'>XHIBIT</a></h1>

            <div></div>

            <?php if(auth()->guard()->guest()): ?>
                <?php if(Route::has('login')): ?>
                <button id="myBtn" class="login">Log in</button>
                <?php endif; ?>

                <?php else: ?>
                <a id="logout" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                    <p id="logoutText">
                        <?php echo e(__('Logout')); ?>

                    </p>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                    </form>
                </a>

                
            <?php endif; ?>
            </div>
        </div>

        <div id="container">
            <!-- side nav bar -->
            <div id="sidenav">
                <h2 id="label">TABLES</h2>   
                <?php echo $__env->yieldContent('sidebar'); ?>

            </div>

            <!-- area that will display tables-->
            <div id="mainSide">
                <div class="formContainer">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
    
    </body>
</html><?php /**PATH C:\Users\reigi\Desktop\ExhibitApp-main\resources\views////formLayout.blade.php ENDPATH**/ ?>